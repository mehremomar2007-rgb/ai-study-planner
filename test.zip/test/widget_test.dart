import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ai_study_planner/main.dart';

void main() {
  testWidgets('StudyPace app works correctly', (WidgetTester tester) async {
    final state = AppState();

    await tester.pumpWidget(
      StudyPaceApp(state: state),
    );

    expect(find.byType(MaterialApp), findsOneWidget);
  });
}